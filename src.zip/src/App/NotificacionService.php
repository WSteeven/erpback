<?php

namespace Src\App;

use App\Models\Notificacion;
use App\Models\User;

class NotificacionService
{
    public function __construct()
    {
    }

    /**
     * La función "obtenerNotificacionesRolBodega" recupera notificaciones en función del rol BODEGA
     * y campos especificados.
     * 
     * @param mixed $campos El parámetro "campos" se utiliza para especificar los campos/columnas que se deben
     * recuperar del modelo "Notificación". Es un parámetro opcional y puede ser una matriz de nombres
     * de campo o una cadena de nombres de campo separados por comas.
     * 
     * @return Illuminate\Database\Eloquent\Collection $results una colección de objetos de Notificación.
     */
    public function obtenerNotificacionesRolBodega($campos)
    {
        if ($campos) {
            $results = Notificacion::ignoreRequest(['campos'])
                ->where('mensaje', 'LIKE', '%pedido recién autorizado en la sucursal%')
                ->orWhere('mensaje', 'LIKE', '%Hay una devolución recién autorizada en la ciudad%')
                ->orWhere('per_destinatario_id', auth()->user()->empleado->id)->filter()->orderBy('id', 'desc')->limit(10)->get($campos);
        } else {
            $results = Notificacion::where('mensaje', 'LIKE', '%pedido recién autorizado en la sucursal%')
                ->orWhere('mensaje', 'LIKE', '%Hay una devolución recién autorizada en la ciudad%')
                ->orWhere('per_destinatario_id', auth()->user()->empleado->id)->filter()->orderBy('id', 'desc')->get();
        }

        return $results;
    }
    public function obtenerNotificacionesRolCompras($campos)
    {
        if ($campos) {
            $results = Notificacion::ignoreRequest(['campos'])
                ->where('mensaje', 'LIKE', '%Preorden de compra N°%')
                ->orWhere('per_destinatario_id', auth()->user()->empleado->id)->filter()->orderBy('id', 'desc')->limit(10)->get($campos);
        } else {
            $results = Notificacion::where('mensaje', 'LIKE', '%Preorden de compra N°%')
                ->orWhere('per_destinatario_id', auth()->user()->empleado->id)->filter()->orderBy('id', 'desc')->get();
        }

        return $results;
    }

    /**
     * La función "obtenerNotificacionesRol" recupera notificaciones en función del rol del usuario y
     * campos especificados.
     * 
     * @param string $rol El parámetro "rol" representa el rol de un usuario. Puede tener valores como "bodega"
     * o "compras" que corresponden a roles específicos en el sistema.
     * @param mixed $campos El parámetro "campos" se utiliza para especificar los campos o columnas que desea
     * recuperar de la base de datos. Es un parámetro opcional y se puede utilizar para limitar la
     * cantidad de datos devueltos en los resultados.
     * 
     * @return Illuminate\Database\Eloquent\Collection una lista de notificaciones.
     */
    public function obtenerNotificacionesRol($rol, $campos)
    {
        $results = [];
        switch ($rol) {
            case User::ROL_BODEGA:
                $results = $this->obtenerNotificacionesRolBodega($campos);
                break;
            case User::ROL_COMPRAS:
                $results = $this->obtenerNotificacionesRolCompras($campos);
                break;
            default:
                if ($campos) $results = Notificacion::ignoreRequest(['campos'])->filter()->where('per_destinatario_id', auth()->user()->empleado->id)->orderBy('id', 'desc')->limit(10)->get($campos);
                else $results = Notificacion::where('per_destinatario_id', auth()->user()->empleado->id)->filter()->orderBy('id', 'desc')->get();
        }

        return $results;
    }
}
