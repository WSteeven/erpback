<?php

namespace Src\Config;

//Seleccionar el id de autorizacion según la tabla autorizaciones
class Autorizaciones
{
  const PENDIENTE = 1;
  const APROBADO = 2;
  const CANCELADO = 3;
}
