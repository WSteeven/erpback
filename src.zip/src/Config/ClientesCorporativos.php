<?php

namespace Src\Config;

//Seleccionar el tipo de reporte de ingreso
enum ClientesCorporativos: int
{
    case TELCONET = 2;
    case NEDETEL = 3;
}
