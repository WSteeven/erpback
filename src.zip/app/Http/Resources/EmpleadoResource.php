<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class EmpleadoResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $controller_method = $request->route()->getActionMethod();
        $modelo = [
            'id' => $this->id,
            'identificacion' => $this->identificacion,
            'nombres' => $this->nombres,
            'apellidos' => $this->apellidos,
            'telefono' => $this->telefono,
            'fecha_nacimiento' => $this->fecha_nacimiento,
            'email' => $this->user ? $this->user->email : '',
            // 'password'=>bcrypt($this->user->password),
            'usuario' => $this->user->name,
            'jefe' => $this->jefe ? $this->jefe->nombres . ' ' . $this->jefe->apellidos : 'N/A',
            'canton' => $this->canton ? $this->canton->canton : 'NO TIENE',
            'estado' => $this->estado, //?Empleado::ACTIVO:Empleado::INACTIVO,
            'cargo' => $this->cargo?->nombre,
            'grupo' => $this->grupo?->nombre,
            'grupo_id' => $this->grupo?->nombre,
            'roles' => implode(', ', $this->user->getRoleNames()->filter(fn ($rol) => $rol !== 'EMPLEADO')->toArray()),
            // 'roles' => $this->user->getRoleNames()->filter(fn ($rol) => $rol !== 'EMPLEADO')->toArray(),
            'cargo' => $this->cargo?->nombre,
            'firma_url' => $this->firma_url ? url($this->firma_url) : null,
            'foto_url' => $this->foto_url ? url($this->foto_url) : null,
            // 'es_responsable_grupo' => $this->es_responsable_grupo,
            // 'es_lider' => $this->esTecnicoLider(),
            'convencional' => $this->convencional? $this->convencional:null,
            'telefono_empresa' => $this->telefono_empresa?$this->telefono_empresa:null,
            'extension' => $this->extension?$this->extension:null,
            'coordenadas' => $this->coordenadas?$this->coordenadas:null,
            'casa_propia' => $this->casa_propia,
            'vive_con_discapacitados' => $this->vive_con_discapacitados,
            'responsable_discapacitados' => $this->responsable_discapacitados,
        ];

        if ($controller_method == 'show') {
            $modelo['jefe'] = $this->jefe_id;
            $modelo['usuario'] = $this->user->name;
            $modelo['canton'] = $this->canton_id;
            $modelo['roles'] = $this->user->getRoleNames();
            $modelo['grupo'] = $this->grupo_id;
            $modelo['cargo'] = $this->cargo_id;
        }

        return $modelo;
    }
}
