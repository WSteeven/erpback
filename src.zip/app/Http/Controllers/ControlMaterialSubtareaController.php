<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControlMaterialTrabajoController extends Controller
{
    //
}
