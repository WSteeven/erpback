<?php

namespace App\Http\Requests\ComprasProveedores;

use Illuminate\Foundation\Http\FormRequest;

class DatoBancarioProveedorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'banco'=>'required|exists:bancos,id',
            'empresa'=>'required|exists:empresas,id',
            'tipo_cuenta'=>'required|string',
            'numero_cuenta'=>'required|string',
            'identificacion'=>'nullable|sometimes|string',
            'nombre_propietario'=>'nullable|sometimes|string',
        ];
    }
}
