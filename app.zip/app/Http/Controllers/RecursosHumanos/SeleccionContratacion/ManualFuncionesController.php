<?php

namespace App\Http\Controllers\RecursosHumanos\SeleccionContratacion;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManualFuncionesController extends Controller
{
    //
}
