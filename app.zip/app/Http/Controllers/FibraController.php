<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FibraController extends Controller
{
    //
}
