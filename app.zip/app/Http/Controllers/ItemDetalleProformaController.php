<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ItemDetalleProformaController extends Controller
{
    //
}
