<?php

namespace App\Http\Controllers\Bodega;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductoEmpleado extends Controller
{
    //
}
