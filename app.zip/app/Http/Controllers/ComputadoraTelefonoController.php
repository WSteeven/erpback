<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ComputadoraTelefonoController extends Controller
{
    //
}
