<?php

namespace App\Http\Controllers;

use App\Events\Bodega\IngresoPorCompraEvent;
use App\Exports\TransaccionBodegaIngresoExport;
use App\Http\Requests\TransaccionBodegaRequest;
use App\Http\Resources\ClienteResource;
use App\Http\Resources\TransaccionBodegaResource;
use App\Models\Cliente;
use App\Models\Condicion;
use App\Models\ConfiguracionGeneral;
use App\Models\DetalleProducto;
use App\Models\DetalleProductoTransaccion;
use App\Models\Devolucion;
use App\Models\Empleado;
use App\Models\EstadoTransaccion;
use App\Models\Inventario;
use App\Models\MaterialEmpleado;
use App\Models\MaterialEmpleadoTarea;
use App\Models\Motivo;
use App\Models\Producto;
use App\Models\TipoTransaccion;
use App\Models\TransaccionBodega;
use App\Models\Transferencia;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Facades\Excel;
use Src\App\TransaccionBodegaIngresoService;
use Src\Config\ClientesCorporativos;
use Src\Shared\Utils;

class TransaccionBodegaIngresoController extends Controller
{
    private $entidad = 'Transacción';
    private TransaccionBodegaIngresoService $servicio;
    public function __construct()
    {
        $this->servicio = new TransaccionBodegaIngresoService();
        $this->middleware('can:puede.ver.transacciones_ingresos')->only('index', 'show');
        $this->middleware('can:puede.crear.transacciones_ingresos')->only('store');
        $this->middleware('can:puede.editar.transacciones_ingresos')->only('update');
        $this->middleware('can:puede.eliminar.transacciones_ingresos')->only('destroy');
    }


    /**
     * Listar
     */
    public function index(Request $request)
    {
        $estado = $request['estado'];
        $tipoTransaccion = TipoTransaccion::where('nombre', TipoTransaccion::INGRESO)->first();
        $motivos = Motivo::where('tipo_transaccion_id', $tipoTransaccion->id)->get('id');
        $results = [];
        if (auth()->user()->hasRole([User::ROL_BODEGA, User::ROL_ADMINISTRADOR])) {
            $results = TransaccionBodega::whereIn('motivo_id', $motivos)->orderBy('id', 'desc')->get();
        }
        if (auth()->user()->hasRole([User::ROL_BODEGA_TELCONET])) {
            $results = TransaccionBodega::whereIn('motivo_id', $motivos)->where('cliente_id', ClientesCorporativos::TELCONET)->orderBy('id', 'desc')->get();
        }
        $results = TransaccionBodegaResource::collection($results);
        return response()->json(compact('results'));
    }

    /**
     * Guardar
     */
    public function store(TransaccionBodegaRequest $request)
    {
        if (auth()->user()->hasRole([User::ROL_COORDINADOR, User::ROL_BODEGA, User::ROL_CONTABILIDAD])) {
            try {
                $datos = $request->validated();
                DB::beginTransaction();
                if ($request->transferencia) $datos['transferencia_id'] = $request->safe()->only(['transferencia'])['transferencia'];
                $datos['autorizacion_id'] = $request->safe()->only(['autorizacion'])['autorizacion'];
                $datos['devolucion_id'] = $request->safe()->only(['devolucion'])['devolucion'];
                $datos['motivo_id'] = $request->safe()->only(['motivo'])['motivo'];
                $datos['solicitante_id'] = $request->safe()->only(['solicitante'])['solicitante'];
                $datos['sucursal_id'] = $request->safe()->only(['sucursal'])['sucursal'];
                $datos['per_autoriza_id'] = $request->safe()->only(['per_autoriza'])['per_autoriza'];
                $datos['cliente_id'] = $request->safe()->only(['cliente'])['cliente'];
                if ($request->per_atiende) $datos['per_atiende_id'] = $request->safe()->only(['per_atiende'])['per_atiende'];
                $datos['estado_id'] = $request->safe()->only(['estado'])['estado'];
                $datos['tarea_id'] = $request->safe()->only(['tarea'])['tarea']; //Comprobar si hay tarea

                // Crear la transaccion
                $transaccion = TransaccionBodega::create($datos);


                if ($request->ingreso_masivo) {
                    //Guardar los productos seleccionados en el detalle
                    foreach ($request->listadoProductosTransaccion as $listado) {
                        $producto = Producto::where('nombre', $listado['producto'])->first();
                        $detalle = DetalleProducto::where('producto_id', $producto->id)->where('descripcion', $listado['descripcion'])->first();
                        if ($listado['serial'] != null) $detalle = DetalleProducto::where('producto_id', $producto->id)->where('descripcion', $listado['descripcion'])->where('serial', $listado['serial'])->first();
                        TransaccionBodega::activarDetalle($detalle); //Aquí se activa el ítem del detalle 
                        $itemInventario = Inventario::where('detalle_id', $detalle->id)->where('condicion_id', $request->condicion)->where('sucursal_id', $request->sucursal)->where('cliente_id', $request->cliente)->first();
                        if (!$itemInventario) {
                            $fila = Inventario::estructurarItem($detalle->id, $request->sucursal, $request->cliente, $request->condicion, $listado['cantidad']);
                            $itemInventario = Inventario::create($fila);
                        } else {
                            $itemInventario->update(['cantidad' => $itemInventario->cantidad + $listado['cantidad']]);
                        }
                        $transaccion->items()->attach($itemInventario->id, ['cantidad_inicial' => $listado['cantidad'],]);

                        //cuando se produce una devolucion de tarea se resta el material del stock de tarea del empleado
                        if ($transaccion->devolucion_id) {
                            $this->servicio->actualizarDevolucion($transaccion, $detalle, $listado['cantidad']);
                            $this->servicio->descontarMaterialesAsignados($listado, $transaccion, $detalle);
                        }
                    }
                } else {
                    foreach ($request->listadoProductosTransaccion as $listado) {
                        // Log::channel('testing')->info('Log', ['item del listado para ingresar cuando no es ingreso masivo', $listado]);
                        $condicion = Condicion::where('nombre', $listado['condiciones'])->first();
                        $producto = Producto::where('nombre', $listado['producto'])->first();
                        $transaccion->transferencia_id ? $detalle = DetalleProducto::find($listado['detalle_id']) : $detalle = DetalleProducto::where('producto_id', $producto->id)->where('descripcion', $listado['descripcion'])->first();
                        if ($listado['serial'] != null) $detalle = DetalleProducto::where('producto_id', $producto->id)->where('descripcion', $listado['descripcion'])->where('serial', $listado['serial'])->first();
                        // $detalle = DetalleProducto::where('producto_id', $producto->id)->where('descripcion', $listado['descripcion'])->first();
                        // $itemInventario = Inventario::where('detalle_id', $detalle->id)->where('condicion_id', $listado['condiciones'])->where('cliente_id', $transaccion->cliente_id)->where('sucursal_id', $transaccion->sucursal_id)->first();
                        $itemInventario = Inventario::where('detalle_id', $detalle->id)->where('condicion_id', $condicion->id)->where('cliente_id', $transaccion->cliente_id)->where('sucursal_id', $transaccion->sucursal_id)->first();
                        if ($itemInventario) {
                            $itemInventario->cantidad = $itemInventario->cantidad + $listado['cantidad'];
                            $itemInventario->save();
                            $transaccion->items()->attach($itemInventario->id, ['cantidad_inicial' => $listado['cantidad']]);
                        } else {
                            $fila = Inventario::estructurarItem($detalle->id, $transaccion->sucursal_id, $transaccion->cliente_id, $condicion->id, $listado['cantidad']);
                            $itemInventario = Inventario::create($fila);
                            $transaccion->items()->attach($itemInventario->id, ['cantidad_inicial' => $listado['cantidad']]);
                        }

                        if ($transaccion->devolucion_id) {
                            $this->servicio->actualizarDevolucion($transaccion, $detalle, $listado['cantidad']);
                            $this->servicio->descontarMaterialesAsignados($listado, $transaccion, $detalle);
                        }
                    }
                }

                DB::commit(); //Se registra la transaccion y sus detalles exitosamente


                //se entiende que si hay un ingreso por transferencia es porque la transferencia llegó a su destino,
                // entonces procedemos a actualizar la transferencia
                if ($transaccion->transferencia_id) {
                    $transferencia = Transferencia::find($transaccion->transferencia_id);
                    $transferencia->estado = Transferencia::COMPLETADO;
                    $transferencia->recibida = true;
                    $transferencia->save();
                }

                if ($transaccion->motivo_id == 1) {
                    //en caso de que sea ingreso por COMPRA A PROVEEDOR se notifica a contabilidad
                    event(new IngresoPorCompraEvent($transaccion, User::ROL_CONTABILIDAD));
                }

                $modelo = new TransaccionBodegaResource($transaccion);
                $mensaje = Utils::obtenerMensaje($this->entidad, 'store');
            } catch (Exception $e) {
                DB::rollBack();
                Log::channel('testing')->info('Log', ['ERROR en el insert de la transaccion de ingreso', $e->getMessage(), $e->getLine()]);
                throw ValidationException::withMessages(['error' => [$e->getMessage()]]);
                return response()->json(['mensaje' => 'Ha ocurrido un error al insertar el registro' . $e->getMessage() . $e->getLine()], 422);
            }

            return response()->json(compact('mensaje', 'modelo'));
        } else return response()->json(compact('Este usuario no puede realizar ingreso de materiales'), 421);
    }

    /**
     * Consultar
     */
    public function show(TransaccionBodega $transaccion)
    {
        // Log::channel('testing')->info('Log', ['Transaccion en el show de ingreso', $transaccion]);
        $modelo = new TransaccionBodegaResource($transaccion);
        return response()->json(compact('modelo'));
    }

    /**
     * Actualizar
     */
    public function update(TransaccionBodegaRequest $request, TransaccionBodega $transaccion)
    {
        $datos = $request->validated();
        // $datos['tipo_id'] = $request->safe()->only(['tipo'])['tipo'];
        $datos['devolucion_id'] = $request->safe()->only(['devolucion'])['devolucion'];
        $datos['motivo_id'] = $request->safe()->only(['motivo'])['motivo'];
        $datos['solicitante_id'] = $request->safe()->only(['solicitante'])['solicitante'];
        $datos['sucursal_id'] = $request->safe()->only(['sucursal'])['sucursal'];
        $datos['per_autoriza_id'] = $request->safe()->only(['per_autoriza'])['per_autoriza'];
        if ($request->per_atiende) $datos['per_atiende_id'] = $request->safe()->only(['per_atiende'])['per_atiende'];
        //datos de las relaciones muchos a muchos
        $datos['autorizacion_id'] = $request->safe()->only(['autorizacion'])['autorizacion'];
        $datos['estado_id'] = $request->safe()->only(['estado'])['estado'];

        //Comprobar si hay tarea
        if ($request->tarea) {
            $datos['tarea_id'] = $request->safe()->only(['tarea'])['tarea'];
        }
        //Comprobar si hay subtarea
        if ($request->subtarea) {
            $datos['subtarea_id'] = $request->safe()->only(['subtarea'])['subtarea'];
        }

        if ($transaccion->solicitante->id === auth()->user()->empleado->id) {
            try {
                DB::beginTransaction();
                //Actualización de la transacción
                $transaccion->update($datos);


                //borrar los registros de la tabla intermedia para guardar los modificados
                $transaccion->detalles()->detach();

                //Guardar los productos seleccionados
                foreach ($request->listadoProductosTransaccion as $listado) {
                    $transaccion->detalles()->attach($listado['id'], ['cantidad_inicial' => $listado['cantidad']]);
                }


                DB::commit();
                $modelo = new TransaccionBodegaResource($transaccion->refresh());
                $mensaje = Utils::obtenerMensaje($this->entidad, 'update');
            } catch (Exception $e) {
                DB::rollBack();
                Log::channel('testing')->info('Log', ['ERROR en el insert de la transaccion de ingreso', $e->getMessage(), $e->getLine()]);
                return response()->json(['mensaje' => 'Ha ocurrido un error al insertar el registro'], 422);
            }

            return response()->json(compact('mensaje', 'modelo'));
        } else {
            //Aqui pregunta si es coordinador o jefe inmediato o bodeguero... solo ellos pueden modificar los datos de las transacciones de los demas
        }

        $message = 'No tienes autorización para modificar esta solicitud';
        $errors = ['message' => $message];
        return response()->json(['errors' => $errors], 422);
    }

    /**
     * Eliminar
     */
    public function destroy(TransaccionBodega $transaccion)
    {
        $transaccion->delete();
        $mensaje = Utils::obtenerMensaje($this->entidad, 'destroy');
        return response()->json(compact('mensaje'));
    }


    /**
     * Anular una transacción de ingreso y revertir el stock del inventario
     */
    public function anular(TransaccionBodega $transaccion)
    {
        // Log::channel('testing')->info('Log', ['Estamos en el metodo de anular el ingreso']);
        $estadoAnulado = EstadoTransaccion::where('nombre', EstadoTransaccion::ANULADA)->first();
        if ($transaccion->estado_id !== $estadoAnulado->id) {
            try {
                DB::beginTransaction();
                $detalles = DetalleProductoTransaccion::where('transaccion_id', $transaccion->id)->get();
                foreach ($detalles as $detalle) {
                    $itemInventario = Inventario::find($detalle['inventario_id']);
                    $itemInventario->cantidad -= $detalle['cantidad_inicial'];
                    $itemInventario->save();
                }
                $transaccion->estado_id = $estadoAnulado->id;
                $transaccion->save();
                DB::commit();
                $mensaje = 'Transacción anulada correctamente';
                $modelo = new TransaccionBodegaResource($transaccion->refresh());
                return response()->json(compact('modelo', 'mensaje'));
            } catch (Exception $e) {
                DB::rollBack();
                Log::channel('testing')->info('Log', ['ERROR al anular la transaccion de ingreso', $e->getMessage(), $e->getLine()]);
                return response()->json(['mensaje' => 'Ha ocurrido un error al anular la transacción'], 422);
            }
        } else {
            // Log::channel('testing')->info('Log', ['La transacción está anulada, ya no se anulará nuevamente']);
            $mensaje = 'La transacción está anulada, ya no se anulará nuevamente';
            $modelo = new TransaccionBodegaResource($transaccion->refresh());
            return response()->json(compact('modelo', 'mensaje'));
        }
    }


    /**
     * Consultar datos sin metodo show
     */
    public function showPreview(TransaccionBodega $transaccion)
    {
        $detalles = TransaccionBodega::listadoProductos($transaccion->id);

        $modelo = new TransaccionBodegaResource($transaccion);

        return response()->json(compact('modelo'), 200);
    }
    /**
     * Imprimir
     */
    public function imprimir(TransaccionBodega $transaccion)
    {
        $configuracion = ConfiguracionGeneral::first();
        $resource = new TransaccionBodegaResource($transaccion);
        $cliente = new ClienteResource(Cliente::find($transaccion->cliente_id));
        $persona_entrega = Empleado::find($transaccion->solicitante_id);
        $persona_atiende = Empleado::find($transaccion->per_atiende_id);
        try {
            // Log::channel('testing')->info('Log', ['ingreso a imprimir', ['transaccion' => $resource->resolve(), 'persona_entrega' => $persona_entrega, 'persona_atiende' => $persona_atiende, 'cliente' => $cliente]]);
            $transaccion = $resource->resolve();
            // Log::channel('testing')->info('Log', ['resource a imprimir', $transaccion]);
            $transaccion['listadoProductosTransaccion'] = TransaccionBodega::listadoProductos($transaccion['id']);;
            // Log::channel('testing')->info('Log', ['resource a completo', $transaccion]);
            $pdf = Pdf::loadView('ingresos.ingreso', compact(['transaccion', 'persona_entrega', 'persona_atiende', 'cliente', 'configuracion']));
            $pdf->setPaper('A5', 'landscape');
            $pdf->render();
            $file = $pdf->output();
            $filename = 'ingreso_' . $resource->id . '_' . time() . '.pdf';
            $ruta = storage_path() . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'ingresos' . DIRECTORY_SEPARATOR . $filename;
            // file_put_contents($ruta, $file); //en caso de que se quiera guardar el documento en el backend
            return $file;
        } catch (Exception $ex) {
            Log::channel('testing')->info('Log', ['ERROR', $ex->getMessage(), $ex->getLine()]);
        }
    }

    /**
     * Reportes
     */
    public function reportes(Request $request)
    {
        // Log::channel('testing')->info('Log', ['Recibido del front', $request->all()]);
        $configuracion = ConfiguracionGeneral::first();
        $results = [];
        $registros = [];
        switch ($request->accion) {
            case 'excel':
                Log::channel('testing')->info('Log', ['Entró en excel']);
                $results = $this->servicio->filtrarIngresoPorTipoFiltro($request);
                $registros = TransaccionBodega::obtenerDatosReporteIngresos($results);
                //imprimir el excel
                return Excel::download(new TransaccionBodegaIngresoExport(collect($registros)), 'reporte.xlsx');
                break;
            case 'pdf':
                Log::channel('testing')->info('Log', ['Entró en pdf']);
                try {
                    $results = $this->servicio->filtrarIngresoPorTipoFiltro($request);
                    $registros = TransaccionBodega::obtenerDatosReporteIngresos($results);
                    $reporte = $registros;
                    $peticion = $request->all();
                    $pdf = Pdf::loadView('bodega.reportes.ingresos_bodega', compact(['reporte', 'peticion', 'configuracion']));
                    $pdf->setPaper('A4', 'landscape');
                    $pdf->render();
                    return $pdf->output();
                } catch (Exception $ex) {
                    Log::channel('testing')->info('Log', ['ERROR', $ex->getMessage(), $ex->getLine()]);
                }
                break;
            default:
                //cuando llega el consultar
                $results = $this->servicio->filtrarIngresoPorTipoFiltro($request);
        }


        $results = TransaccionBodegaResource::collection($results);
        return response()->json(compact('results'));
    }
}
