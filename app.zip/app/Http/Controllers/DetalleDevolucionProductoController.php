<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DetalleDevolucionProductoController extends Controller
{
    private $entidad = 'Detalle de producto en Devolución';

    
}
