<?php

namespace App\Http\Controllers\ComprasProveedores;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ItemPagoProveedoresController extends Controller
{
    //
}
