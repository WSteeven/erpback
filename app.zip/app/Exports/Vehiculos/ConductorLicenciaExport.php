<?php

namespace App\Exports\Vehiculos;

use Maatwebsite\Excel\Concerns\FromCollection;

class ConductorLicenciaExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
