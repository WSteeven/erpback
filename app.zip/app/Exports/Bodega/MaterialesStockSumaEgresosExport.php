<?php

namespace App\Exports\Bodega;

use Maatwebsite\Excel\Concerns\FromCollection;

class MaterialesStockSumaEgresosExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
