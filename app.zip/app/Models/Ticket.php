<?php

namespace App\Models;

use App\Traits\UppercaseValuesTrait;
use eloquentFilter\QueryFilter\ModelFilters\Filterable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use OwenIt\Auditing\Auditable as AuditableModel;

class Ticket extends Model implements Auditable
{
    use HasFactory, AuditableModel, Filterable, UppercaseValuesTrait;

    // Estados de un ticket
    const ASIGNADO = 'ASIGNADO';
    const EJECUTANDO = 'EJECUTANDO';
    const PAUSADO = 'PAUSADO';
    const REASIGNADO = 'REASIGNADO';
    const CANCELADO = 'CANCELADO';
    const FINALIZADO_SIN_SOLUCION = 'FINALIZADO SIN SOLUCIÓN';
    const FINALIZADO_SOLUCIONADO = 'FINALIZADO SOLUCIONADO';
    const CALIFICADO = 'CALIFICADO';

    // Prioridad
    const ALTA = 'ALTA';
    const MEDIA = 'MEDIA';
    const BAJA = 'BAJA';
    const EMERGENCIA = 'EMERGENCIA';

    protected $table = 'tickets';
    protected $fillable = [
        'codigo',
        'asunto',
        'descripcion',
        'prioridad',
        'fecha_hora_limite',
        'estado',
        'observaciones_solicitante',
        'calificacion_solicitante',
        'solicitante_id',
        'responsable_id',
        'departamento_responsable_id',
        'tipo_ticket_id',
    ];
}
