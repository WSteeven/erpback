<?php

namespace App\Models\ComprasProveedores;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemDetallePreordenCompra extends Model
{
    use HasFactory;
    protected $table = 'cmp_item_detalle_preorden_compra';
    
}
