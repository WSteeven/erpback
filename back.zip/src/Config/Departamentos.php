<?php

namespace Src\Config;

enum Departamentos: int {
    case RR_HH = 7;
}