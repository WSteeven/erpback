<?php

namespace Src\App\RecursosHumanos\SeleccionContratacion;

use App\Models\RecursosHumanos\SeleccionContratacion\SolicitudPuestoEmpleo;

class SolicitudPuestoEmpleoService
{

    protected SolicitudPuestoEmpleo $solicitudPuestoEmpleo;


    public function __construct()
    {

    }



}
