<?php

namespace App\Http\Controllers;

use App\Http\Requests\MarcaRequest;
use App\Http\Resources\CategoriaResource;
use App\Http\Resources\MarcaResource;
use App\Models\Marca;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Src\Shared\Utils;

class MarcaController extends Controller
{
    private $entidad = 'Marca';
    public function __construct()
    {
        $this->middleware('can:puede.ver.marcas')->only('index', 'show');
        $this->middleware('can:puede.crear.marcas')->only('store');
        $this->middleware('can:puede.editar.marcas')->only('update');
        $this->middleware('can:puede.eliminar.marcas')->only('destroy');
    }

    /**
     * Listar
     */
    public function index(Request $request)
    {
        $page = $request['page'];
        $campos = explode(',', $request['campos']);
        $search = $request['search'];
        $results = [];
        if ($request['campos']) {
            $results = Marca::all($campos);
            Log::channel('testing')->info('Log', ['marcas en el primer if con campos:',$campos, $results]);
            return response()->json(compact('results'));
        } else if ($page) {
            $results = Marca::simplePaginate($request['offset']);
            Log::channel('testing')->info('Log', ['marcas en el elseif:', $results]);
            // MarcaResource::collection($results);
            // $results->appends(['offset' => $request['offset']]);
        } else {
            $results = Marca::all();
            Log::channel('testing')->info('Log', ['marcas en el else:', $results]);
            // MarcaResource::collection($results);
        }
        if ($search) {
            $marca = Marca::select('id')->where('nombre', 'LIKE', '%' . $search . '%')->first();
            Log::channel('testing')->info('Log', ['marcas en no se que hago aqui:', $marca]);
            if ($marca) $results = MarcaResource::collection(Marca::where('id', $marca->id)->get());
        }

        MarcaResource::collection($results);
        return response()->json(compact('results'));
    }


    /**
     * Guardar
     */
    public function store(MarcaRequest $request)
    {
        //Respuesta
        $modelo = Marca::create($request->validated());
        $modelo = new MarcaResource($modelo);
        $mensaje = Utils::obtenerMensaje($this->entidad, 'store');

        return response()->json(compact('mensaje', 'modelo'));
    }


    /**
     * Consultar
     */
    public function show(Marca $marca)
    {
        $modelo = new MarcaResource($marca);
        return response()->json(compact('modelo'));
    }


    /**
     * Actualizar
     */
    public function update(MarcaRequest $request, Marca  $marca)
    {

        //Respuesta
        $marca->update($request->validated());
        $modelo = new MarcaResource($marca->refresh());
        $mensaje = Utils::obtenerMensaje($this->entidad, 'update');

        return response()->json(compact('mensaje', 'modelo'));
    }

    /**
     * Eliminar
     */
    public function destroy(Marca $marca)
    {
        $marca->delete();
        $mensaje = Utils::obtenerMensaje($this->entidad, 'destroy');
        return response()->json(compact('mensaje'));
    }
}
